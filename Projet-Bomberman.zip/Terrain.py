class Terrain:
    LISTE = (0, 1, 2)
    VIDE = 0
    BRIQUE = 1
    PILIER = 2
