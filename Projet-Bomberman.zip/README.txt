Lancez le fichier Interface.py pour lancer le Bomberman.


	Touches :

- Pour le joueur 1 (rouge)
	Z: haut
	Q: gauche
	S: bas
	D: droite
	E: pose d'une bombe

- Pour le joueur 2 (bleu)
	flèches directionnelles pour les déplacements
	1 (pavé numérique) ou shift droit: pose d'une bombe